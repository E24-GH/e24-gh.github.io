ZEN ファームウェア
==================

ZEN Configurator に対応したファームウェアです。

  ZEN Configurator
  https://e24-gh.github.io/zen/configurator/

Configurator は、ZEN を USB でつないでブラウザから設定する画面です。
キー配置とトラックボールの設定を、GitHub を使わずに変更できます。
Chrome または Edge でお使いください。


書き込むファイル
----------------

右手（トラックボールのある方）は、お使いのセンサーに合うものを1つ。

  PMW3610（標準）  zen_right_trackball_pmw3610_central-bmp_boost-zmk.uf2
  PAW3222          zen_right_trackball_paw3222_central-bmp_boost-zmk.uf2
  トラックパッド    zen_right_trackpad_central-bmp_boost-zmk.uf2

左手も、お使いの構成に合うものを1つ。

  トラックパッドなし（標準）  zen_left_peripheral-bmp_boost-zmk.uf2
  トラックパッドあり          zen_left_trackpad_peripheral-bmp_boost-zmk.uf2

標準構成なら、右手は PMW3610、左手はトラックパッドなしの2つです。


書き込み方
----------

1. 対応コントローラをブートローダーモードにします
2. 出てきたドライブに UF2 ファイルをコピーします
3. 左右それぞれ同じ手順で書き込みます
4. 右手を USB でつなぎ、Configurator を開きます


設定を元に戻したいとき
----------------------

Configurator の「プリセット」→「出荷時の設定に戻す」で、Configurator から
変更したキー配置とマウス操作をキーボードから消せます。ファームウェアに
入っている元の設定に戻ります。無線の登録は消えません。

無線接続そのものがうまくいかない場合は、同梱の
settings_reset-bmp_boost-zmk.uf2 を使います。こちらは無線の登録も消えます。

  1. PC や Mac の接続設定から ZEN を削除します
  2. settings_reset-bmp_boost-zmk.uf2 を書き込みます
  3. USB を外します
  4. ZEN の電源を入れます
  5. もう一度、上の通常ファームウェアを書き込みます
  6. 接続設定から ZEN を再接続します


コンボ・マクロを使いたい方へ
----------------------------

コンボとマクロはファームウェアに焼き込まれているため、Configurator からは
変更できません。これらを編集したい場合は、GitHub でリポジトリを fork して
config/keymap.keymap を編集し、GitHub Actions でビルドしてください。

  https://github.com/E24-GH/zen-keyboard

その場合も、キー配置そのものは Configurator から変更できます。

  キー配置は Configurator、コンボとマクロは config/keymap.keymap。

同じキーを両方で変更すると、Configurator で設定した内容が優先されます。
config/keymap.keymap 側の変更を反映させたいときは、先に Configurator の
「出荷時の設定に戻す」を実行してください。
